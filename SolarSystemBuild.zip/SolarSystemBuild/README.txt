WASD to move forward, backward, left, and right
Q and E to move up and down
Space to spawn a planet
Click to reveal mouse to test time scale slider (CANNOT GO BACK TO CAMERA MODE)
Alt-F4 to close

The smaller body in the scene is a moon, but unfortunately is not working entirely properly

Made by Ben Hubner and Cameron Schneider