WASD to move forward, backward, left, and right
Q and E to move up and down
Space to spawn a planet
Escape to reveal mouse to test time scale slider, hit again to return to camera mode
Alt-F4 to close

The smaller body in the scene is a moon, but unfortunately is not working entirely properly

Made by Ben Hubner and Cameron Schneider